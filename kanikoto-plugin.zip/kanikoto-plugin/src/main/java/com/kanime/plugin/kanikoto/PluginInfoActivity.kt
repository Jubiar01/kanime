package com.kanime.plugin.kanikoto

import android.app.Activity
import android.os.Bundle
import android.view.Gravity
import android.widget.LinearLayout
import android.widget.TextView

/**
 * Minimal info screen (not shown in launcher) so Android & Play Protect see a transparent,
 * legitimate plugin component with proper metadata and <queries><intent> discovery support.
 */
class PluginInfoActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(64, 64, 64, 64)
            setBackgroundColor(0xFF0D0F18.toInt())
        }
        val title = TextView(this).apply {
            text = "KAnikoto Plugin for KAnime"
            textSize = 20f
            setTextColor(0xFFFFFFFF.toInt())
            gravity = Gravity.CENTER
        }
        val subtitle = TextView(this).apply {
            text = "\nThis is an official streaming source plugin for the KAnime app.\nOpen KAnime to manage or use this plugin."
            textSize = 14f
            setTextColor(0xFFC7CAD9.toInt())
            gravity = Gravity.CENTER
        }
        layout.addView(title)
        layout.addView(subtitle)
        setContentView(layout)
    }
}
