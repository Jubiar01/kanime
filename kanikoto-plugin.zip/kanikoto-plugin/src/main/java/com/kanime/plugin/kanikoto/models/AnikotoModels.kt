package com.kanime.plugin.kanikoto.models

data class AnikotoEpisode(
    val num: Double,
    val id: String,
    val title: String
)

data class AnikotoServer(
    val name: String,
    val sourceId: String,
    val type: String // "sub", "dub", "raw"
)

data class AnikotoSubtitle(
    val lang: String,
    val url: String,
    val isDefault: Boolean = false
)

data class AnikotoStream(
    val embedUrl: String,
    val m3u8: String?,
    val referer: String? = null,
    val subtitles: List<AnikotoSubtitle> = emptyList(),
    val serverName: String,
    val type: String = "hls" // "hls", "iframe"
)

data class AnikotoSearchResult(
    val slug: String,
    val title: String,
    val japaneseTitle: String? = null
)
