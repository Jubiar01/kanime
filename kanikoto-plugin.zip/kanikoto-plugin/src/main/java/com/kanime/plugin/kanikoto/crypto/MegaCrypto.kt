package com.kanime.plugin.kanikoto.crypto

import android.util.Base64
import org.json.JSONObject
import javax.crypto.Cipher
import javax.crypto.Mac
import javax.crypto.spec.IvParameterSpec
import javax.crypto.spec.SecretKeySpec

object MegaCrypto {

    const val DEFAULT_SOURCE_ENC_KEY = "i?LMTAx0Q6,:}50U"
    const val DEFAULT_SOURCE_ENC_IV = "W0;27ToaUpl_P%'c"
    const val DEFAULT_CDN_TOKEN_SECRET = "MpCdnT0k3n!9f2K#xQ7vL5mR8wN1pY4s"

    fun decryptMegaPlaySource(value: String?, script: String? = null): String? {
        if (value.isNullOrBlank()) return null

        var b64 = value.replace('-', '+').replace('_', '/')
        val rem = b64.length % 4
        if (rem != 0) {
            b64 += "=".repeat(4 - rem)
        }

        val encrypted = try {
            Base64.decode(b64, Base64.DEFAULT)
        } catch (e: Exception) {
            return null
        }

        if (encrypted.isEmpty() || encrypted.size % 16 != 0) return null

        // 1. Try known MegaPlay keys
        val primaryResult = tryDecryptWithKeyIv(
            encrypted,
            DEFAULT_SOURCE_ENC_KEY,
            DEFAULT_SOURCE_ENC_IV,
            DEFAULT_CDN_TOKEN_SECRET
        )
        if (!primaryResult.isNullOrBlank()) return primaryResult

        // 2. Try dynamically extracting keys if script is provided
        if (!script.isNullOrBlank()) {
            val keyMatch = Regex("""SOURCE_ENC_KEY\s*=\s*["']([^"']+)["']""").find(script)?.groupValues?.get(1)
            val ivMatch = Regex("""SOURCE_ENC_IV\s*=\s*["']([^"']+)["']""").find(script)?.groupValues?.get(1)
            val secretMatch = Regex("""CDN_TOKEN_SECRET\s*=\s*["']([^"']+)["']""").find(script)?.groupValues?.get(1)

            if (keyMatch != null && ivMatch != null) {
                val dynResult = tryDecryptWithKeyIv(
                    encrypted,
                    keyMatch,
                    ivMatch,
                    secretMatch ?: DEFAULT_CDN_TOKEN_SECRET
                )
                if (!dynResult.isNullOrBlank()) return dynResult
            }

            // 3. Fallback: string scanning heuristic
            val allStrings = getScriptStrings(script)
            val candidateValues = allStrings.filter { it.toByteArray(Charsets.UTF_8).size in 1..32 }
            val ivs = candidateValues.filter { it.toByteArray(Charsets.UTF_8).size == 16 }

            for (k in candidateValues) {
                for (iv in ivs) {
                    val res = tryDecryptWithKeyIv(encrypted, k, iv, DEFAULT_CDN_TOKEN_SECRET)
                    if (!res.isNullOrBlank()) return res
                }
            }
        }

        return null
    }

    private fun tryDecryptWithKeyIv(
        encrypted: ByteArray,
        keyStr: String,
        ivStr: String,
        signingKey: String
    ): String? {
        return try {
            val keyBytes = ByteArray(32)
            val keySrc = keyStr.toByteArray(Charsets.UTF_8)
            System.arraycopy(keySrc, 0, keyBytes, 0, minOf(keySrc.size, 32))

            val ivBytes = ByteArray(16)
            val ivSrc = ivStr.toByteArray(Charsets.UTF_8)
            System.arraycopy(ivSrc, 0, ivBytes, 0, minOf(ivSrc.size, 16))

            val cipher = Cipher.getInstance("AES/CBC/PKCS5Padding")
            val keySpec = SecretKeySpec(keyBytes, "AES")
            val ivSpec = IvParameterSpec(ivBytes)
            cipher.init(Cipher.DECRYPT_MODE, keySpec, ivSpec)
            val decrypted = cipher.doFinal(encrypted)
            val jsonStr = String(decrypted, Charsets.UTF_8)

            val json = JSONObject(jsonStr)
            val file = json.optString("file").takeIf { it.isNotBlank() }
                ?: json.optString("url").takeIf { it.isNotBlank() }
                ?: json.optJSONObject("sources")?.optString("file")?.takeIf { it.isNotBlank() }
                ?: json.optJSONArray("sources")?.optJSONObject(0)?.optString("file")?.takeIf { it.isNotBlank() }

            if (!file.isNullOrBlank()) {
                signMegaPlayUrl(file, signingKey)
            } else null
        } catch (e: Exception) {
            null
        }
    }

    fun signMegaPlayUrl(value: String, signingKey: String = DEFAULT_CDN_TOKEN_SECRET): String {
        if (value.contains("token=")) return value

        val regex = Regex("""/([a-f0-9]{32})/([a-f0-9]{32})/""", RegexOption.IGNORE_CASE)
        val match = regex.find(value) ?: return value

        val pathKey = "${match.groupValues[1].lowercase()}/${match.groupValues[2].lowercase()}"
        val exp = (System.currentTimeMillis() / 1000) + 90
        val payload = "$exp|$pathKey"

        return try {
            val mac = Mac.getInstance("HmacSHA256")
            val keySpec = SecretKeySpec(signingKey.toByteArray(Charsets.UTF_8), "HmacSHA256")
            mac.init(keySpec)
            val rawSig = mac.doFinal(payload.toByteArray(Charsets.UTF_8))
            val signature = Base64.encodeToString(rawSig, Base64.URL_SAFE or Base64.NO_WRAP or Base64.NO_PADDING)
            val payloadB64 = Base64.encodeToString(payload.toByteArray(Charsets.UTF_8), Base64.URL_SAFE or Base64.NO_WRAP or Base64.NO_PADDING)
            val token = "$payloadB64.$signature"

            val separator = if (value.contains("?")) "&" else "?"
            "$value${separator}token=$token"
        } catch (e: Exception) {
            value
        }
    }

    private fun getScriptStrings(script: String): List<String> {
        val strings = mutableListOf<String>()
        var index = 0
        var previous: Char? = null

        while (index < script.length) {
            val char = script[index]
            if (char == '\'' || char == '"') {
                if (previous != '\\') {
                    val end = script.indexOf(char, index + 1)
                    if (end != -1) {
                        val slice = script.substring(index + 1, end)
                        if (slice.isNotBlank() && !slice.contains('\n')) {
                            strings.add(slice)
                        }
                        index = end + 1
                        previous = null
                        continue
                    }
                }
            }
            if (!char.isWhitespace()) previous = char
            index++
        }
        return strings.distinct()
    }
}
