package com.kanime.plugin.kanikoto

import android.content.ContentProvider
import android.content.ContentValues
import android.database.Cursor
import android.net.Uri
import android.os.Bundle
import org.json.JSONArray
import org.json.JSONObject

class KanikotoContentProvider : ContentProvider() {

    override fun onCreate(): Boolean = true

    override fun call(method: String, arg: String?, extras: Bundle?): Bundle {
        val bundle = Bundle()
        when (method) {
            "ping" -> {
                bundle.putBoolean("active", true)
                bundle.putString("id", "kanikoto")
                bundle.putString("name", "KAnikoto Extractor")
                bundle.putString("version", "1.0.1")
                bundle.putString("lang", "EN")
                bundle.putString("author", "KAnime Official")
            }

            "testConnection" -> {
                val (ok, msg) = KAnikoto.testConnection()
                bundle.putBoolean("success", ok)
                bundle.putString("message", msg)
            }

            "search" -> {
                val query = arg ?: ""
                val list = KAnikoto.searchAnikoto(query)
                val ja = JSONArray()
                for (item in list) {
                    val jo = JSONObject()
                    jo.put("slug", item.slug)
                    jo.put("title", item.title)
                    item.japaneseTitle?.let { jo.put("japaneseTitle", it) }
                    ja.put(jo)
                }
                bundle.putString("result", ja.toString())
            }

            "findSlug" -> {
                val title = arg ?: ""
                val slug = KAnikoto.findAnikotoSlug(title)
                bundle.putString("slug", slug)
            }

            "getEpisodes" -> {
                val slug = arg ?: ""
                val list = KAnikoto.getAnikotoEpisodes(slug)
                val ja = JSONArray()
                for (ep in list) {
                    val jo = JSONObject()
                    jo.put("num", ep.num)
                    jo.put("id", ep.id)
                    jo.put("title", ep.title)
                    ja.put(jo)
                }
                bundle.putString("result", ja.toString())
            }

            "getServers" -> {
                val episodeId = arg ?: ""
                val list = KAnikoto.getAnikotoServers(episodeId)
                val ja = JSONArray()
                for (srv in list) {
                    val jo = JSONObject()
                    jo.put("name", srv.name)
                    jo.put("sourceId", srv.sourceId)
                    jo.put("type", srv.type)
                    ja.put(jo)
                }
                bundle.putString("result", ja.toString())
            }

            "getStream" -> {
                val sourceId = arg ?: ""
                val stream = KAnikoto.getAnikotoEmbedUrl(sourceId)
                if (stream != null) {
                    val jo = JSONObject()
                    jo.put("embedUrl", stream.embedUrl)
                    stream.m3u8?.let { jo.put("m3u8", it) }
                    stream.referer?.let { jo.put("referer", it) }
                    jo.put("serverName", stream.serverName)
                    jo.put("type", stream.type)

                    val subsArray = JSONArray()
                    for (sub in stream.subtitles) {
                        val so = JSONObject()
                        so.put("lang", sub.lang)
                        so.put("url", sub.url)
                        so.put("default", sub.isDefault)
                        subsArray.put(so)
                    }
                    jo.put("subtitles", subsArray)
                    bundle.putString("result", jo.toString())
                }
            }
        }
        return bundle
    }

    override fun query(uri: Uri, projection: Array<out String>?, selection: String?, selectionArgs: Array<out String>?, sortOrder: String?): Cursor? = null
    override fun getType(uri: Uri): String? = "vnd.android.cursor.dir/vnd.com.kanime.plugin"
    override fun insert(uri: Uri, values: ContentValues?): Uri? = null
    override fun delete(uri: Uri, selection: String?, selectionArgs: Array<out String>?): Int = 0
    override fun update(uri: Uri, values: ContentValues?, selection: String?, selectionArgs: Array<out String>?): Int = 0
}
