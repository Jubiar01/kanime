package com.kanime.plugin.kanikoto

import android.util.Base64
import android.util.Log
import com.kanime.plugin.kanikoto.crypto.MegaCrypto
import com.kanime.plugin.kanikoto.models.*
import org.json.JSONObject
import org.jsoup.Jsoup
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URI
import java.net.URL
import java.net.URLDecoder
import java.net.URLEncoder
import java.util.zip.GZIPInputStream

object KAnikoto {

    private const val TAG = "KAnikoto"
    private const val CONNECT_TIMEOUT_MS = 15_000
    private const val READ_TIMEOUT_MS = 15_000
    private const val MAX_REDIRECTS = 5

    var baseUrl: String = "https://anikototv.bz"

    private const val UA =
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36"

    private val KIWI_MAPPER_URLS = listOf(
        "https://mapper.nekostream.site/api/mal",
        "https://mapper.mewcdn.online/api/mal"
    )

    private fun openConnection(
        url: String,
        method: String = "GET",
        referer: String? = null,
        isAjax: Boolean = false
    ): HttpURLConnection {
        var currentUrl = url
        repeat(MAX_REDIRECTS + 1) {
            val conn = (URL(currentUrl).openConnection() as HttpURLConnection).apply {
                requestMethod = method
                connectTimeout = CONNECT_TIMEOUT_MS
                readTimeout = READ_TIMEOUT_MS
                instanceFollowRedirects = false
                useCaches = false
                setRequestProperty("User-Agent", UA)
                setRequestProperty(
                    "Accept",
                    if (isAjax) "*/*" else "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,*/*;q=0.8"
                )
                setRequestProperty("Accept-Language", "en-US,en;q=0.9")
                setRequestProperty("Connection", "keep-alive")
                setRequestProperty("Referer", referer ?: "$baseUrl/")
                if (isAjax) {
                    setRequestProperty("X-Requested-With", "XMLHttpRequest")
                }
            }

            val code = conn.responseCode
            if (code in 300..399) {
                val location = conn.getHeaderField("Location")
                if (!location.isNullOrBlank()) {
                    conn.disconnect()
                    currentUrl = URI(currentUrl).resolve(location).toString()
                    return@repeat
                }
            }
            return conn
        }
        throw IOException("Too many redirects for $url")
    }

    private fun httpGet(url: String, referer: String? = null, isAjax: Boolean = false): String {
        val conn = openConnection(url, method = "GET", referer = referer, isAjax = isAjax)
        return try {
            if (conn.responseCode !in 200..299) return ""
            val rawStream = conn.inputStream
            val stream = if ("gzip".equals(conn.contentEncoding, ignoreCase = true)) {
                GZIPInputStream(rawStream)
            } else {
                rawStream
            }
            stream.bufferedReader(Charsets.UTF_8).use { it.readText() }
        } finally {
            conn.disconnect()
        }
    }

    // ── Title Scoring ──────────────────────────────────────────
    private fun normalizeTitle(title: String): String {
        return title.lowercase()
            .replace("&", " and ")
            .replace(Regex("[’']"), "")
            .replace(Regex("[^a-z0-9]+"), " ")
            .trim()
            .replace(Regex("\\s+"), " ")
    }

    fun scoreTitle(query: String, title: String): Int {
        val needle = normalizeTitle(query)
        val hay = normalizeTitle(title)
        if (needle.isBlank() || hay.isBlank()) return 0
        if (hay == needle) return 100
        if (hay.startsWith("$needle ") || hay.startsWith("$needle:")) return 90

        val queryTokens = needle.split(" ").filter { it.isNotBlank() }
        val titleTokens = hay.split(" ").filter { it.isNotBlank() }
        if (queryTokens.size < 2 || titleTokens.size < 2) return 0

        val overlap = queryTokens.count { titleTokens.contains(it) }
        val queryCoverage = overlap.toDouble() / queryTokens.size
        val titleCoverage = overlap.toDouble() / titleTokens.size

        if (queryCoverage >= 0.9 && titleCoverage >= 0.6) return 75
        return 0
    }

    // ── Search & Slug Resolution ───────────────────────────────
    fun searchAnikoto(query: String): List<AnikotoSearchResult> {
        return try {
            val encoded = URLEncoder.encode(query, "UTF-8")
            val html = httpGet("$baseUrl/filter?keyword=$encoded")
            val doc = Jsoup.parse(html)
            val results = mutableListOf<AnikotoSearchResult>()

            val elements = doc.select(".items.flw-wrap .film_list-wrap .flw-item, .film_list-wrap .flw-item, .ani.items .item, section .items .item")
            for (el in elements) {
                val anchor = if (el.tagName() == "a") el else el.selectFirst("a") ?: continue
                val href = anchor.attr("href")
                val slug = href.replace(Regex("^https?://[^/]+"), "")
                    .replace("/watch/", "")
                    .replace(Regex("/ep-\\d+$"), "")
                    .trim('/')

                val titleAnchor = el.selectFirst(".name, .d-title") ?: anchor
                val title = titleAnchor.text().trim().ifBlank { anchor.attr("title").trim() }
                val jpTitle = titleAnchor.attr("data-jp").ifBlank { anchor.attr("data-jp") }.takeIf { it.isNotBlank() }

                if (slug.isNotBlank() && title.isNotBlank()) {
                    results.add(AnikotoSearchResult(slug, title, jpTitle))
                }
            }
            results
        } catch (e: Exception) {
            Log.e(TAG, "searchAnikoto error", e)
            emptyList()
        }
    }

    fun findAnikotoSlug(title: String): String? {
        val noPossessive = title.replace(Regex("[’']s\\b", RegexOption.IGNORE_CASE), "")
        val variants = listOf(
            title,
            noPossessive,
            title.replace("'", "").replace("’", ""),
            title.replace("+", " "),
            noPossessive.replace("+", " ")
        ).filter { it.trim().length >= 4 }.distinct()

        val allResults = mutableListOf<AnikotoSearchResult>()
        for (variant in variants) {
            val hits = searchAnikoto(variant)
            for (item in hits) {
                val score1 = scoreTitle(title, item.title)
                val score2 = item.japaneseTitle?.let { scoreTitle(title, it) } ?: 0
                if (maxOf(score1, score2) == 100) {
                    return item.slug
                }
            }
            allResults.addAll(hits)
        }

        val unique = allResults.distinctBy { it.slug }
        if (unique.isEmpty()) return null

        val ranked = unique.map { item ->
            val score1 = scoreTitle(title, item.title)
            val score2 = item.japaneseTitle?.let { scoreTitle(title, it) } ?: 0
            item to maxOf(score1, score2)
        }.filter { it.second >= 75 }.sortedByDescending { it.second }

        return ranked.firstOrNull()?.first?.slug
    }

    // ── Episode List ───────────────────────────────────────────
    fun getAnikotoEpisodes(slug: String): List<AnikotoEpisode> {
        val episodes = mutableListOf<AnikotoEpisode>()
        try {
            val html = httpGet("$baseUrl/watch/$slug")
            val doc = Jsoup.parse(html)
            val watchMain = doc.selectFirst("#watch-main")
            val animeId = watchMain?.attr("data-id").orEmpty()

            if (animeId.isNotBlank() && doc.select("#w-episodes a").isEmpty()) {
                val ajaxHtml = httpGet("$baseUrl/ajax/episode/list/$animeId", "$baseUrl/watch/$slug", isAjax = true)
                try {
                    val json = JSONObject(ajaxHtml)
                    val result = json.optString("result", "")
                    if (result.isNotBlank()) {
                        doc.selectFirst("#w-episodes")?.html(result)
                    }
                } catch (e: Exception) {
                    // Ignore json parse error if it returns raw html
                }
            }

            val items = doc.select("#w-episodes ul.ep-range li a, #w-episodes a[href], #w-episodes a[data-num]")
            for (el in items) {
                val href = el.attr("href")
                if (!href.contains("/watch/") && el.attr("data-num").isBlank()) continue

                val epNumRaw = el.attr("data-num").ifBlank {
                    el.selectFirst(".number, .d-title, span")?.text()?.trim()
                        ?: href.substringAfter("/ep-", "")
                }
                val num = epNumRaw.toDoubleOrNull() ?: continue
                val epTitle = el.attr("title").ifBlank { "Episode $epNumRaw" }
                val dataIds = el.attr("data-ids").ifBlank { el.attr("data-id") }
                val dataMal = el.attr("data-mal")
                val dataTimestamp = el.attr("data-timestamp")

                episodes.add(
                    AnikotoEpisode(
                        num = num,
                        id = "$slug::$num::$dataIds::$dataMal::$dataTimestamp",
                        title = epTitle
                    )
                )
            }
        } catch (e: Exception) {
            Log.e(TAG, "getAnikotoEpisodes error", e)
        }
        return episodes.distinctBy { it.num }.sortedBy { it.num }
    }

    // ── Server List ────────────────────────────────────────────
    fun getAnikotoServers(episodeId: String): List<AnikotoServer> {
        val parts = episodeId.split("::")
        if (parts.size < 2) return emptyList()
        val slug = parts[0]
        val epNumStr = parts[1]
        val dataIds = parts.getOrNull(2).orEmpty()
        val dataMal = parts.getOrNull(3).orEmpty()
        val dataTimestamp = parts.getOrNull(4).orEmpty()

        val servers = mutableListOf<AnikotoServer>()

        if (dataIds.isNotBlank()) {
            try {
                val encodedDataIds = URLEncoder.encode(dataIds, "UTF-8")
                val ajaxRes = httpGet("$baseUrl/ajax/server/list?servers=$encodedDataIds", "$baseUrl/watch/$slug", isAjax = true)
                val html = try {
                    JSONObject(ajaxRes).optString("result", ajaxRes)
                } catch (e: Exception) {
                    ajaxRes
                }
                val doc = Jsoup.parse(html)
                for (el in doc.select(".server, li")) {
                    val linkId = el.attr("data-link-id")
                    if (linkId.isBlank()) continue
                    val typeContainer = el.parents().firstOrNull { it.hasClass("type") }
                    val dataType = typeContainer?.attr("data-type")?.lowercase()
                        ?: typeContainer?.selectFirst("label, .name")?.text()?.lowercase().orEmpty()
                    val svId = el.attr("data-sv-id")
                    val name = el.text().trim().ifBlank { "Server" }
                    val type = when {
                        dataType.contains("dub") -> "dub"
                        dataType.contains("raw") -> "raw"
                        else -> "sub"
                    }
                    val encodedName = URLEncoder.encode(name, "UTF-8")
                    servers.add(
                        AnikotoServer(
                            name = name,
                            sourceId = "$slug::$epNumStr::reg::$linkId::$svId::$encodedName",
                            type = type
                        )
                    )
                }
            } catch (e: Exception) {
                Log.e(TAG, "getAnikotoServers error", e)
            }
        }

        if (dataMal.isNotBlank() && dataTimestamp.isNotBlank()) {
            servers.add(AnikotoServer("Kiwi Stream (sub)", "kiwi::$dataMal::$epNumStr::$dataTimestamp::sub", "sub"))
            servers.add(AnikotoServer("Kiwi Stream (dub)", "kiwi::$dataMal::$epNumStr::$dataTimestamp::dub", "dub"))
        }

        return servers
    }

    // ── Stream Resolution ──────────────────────────────────────
    fun getAnikotoEmbedUrl(sourceId: String): AnikotoStream? {
        val parts = sourceId.split("::")
        if (parts.isEmpty()) return null

        if (parts[0] == "kiwi" && parts.size >= 5) {
            val malId = parts[1]
            val epNum = parts[2]
            val timestamp = parts[3]
            val type = parts[4]
            return resolveKiwi(malId, epNum, timestamp, type)
        }

        val slug = parts.getOrNull(0) ?: return null
        val epNumStr = parts.getOrNull(1) ?: return null
        val linkId = parts.getOrNull(3) ?: return null
        val svId = parts.getOrNull(4).orEmpty()
        val serverName = parts.getOrNull(5)?.let {
            try { URLDecoder.decode(it, "UTF-8") } catch (e: Exception) { "Anikoto" }
        } ?: "Anikoto"

        return try {
            val svParam = if (svId.isNotBlank()) "&sv=$svId" else ""
            val epReferer = "$baseUrl/watch/$slug/ep-$epNumStr"
            val encodedLinkId = URLEncoder.encode(linkId, "UTF-8")
            val res = httpGet("$baseUrl/ajax/server?get=$encodedLinkId$svParam", epReferer, isAjax = true)
            val json = JSONObject(res)
            val embedUrl = json.optJSONObject("result")?.optString("url") ?: return null

            val lower = serverName.lowercase()
            if (lower.contains("vidstream") || lower.contains("vidplay") || lower.contains("vid-")) {
                val vidStream = resolveVidstream(embedUrl, epReferer)
                if (vidStream != null) return vidStream.copy(serverName = serverName)
            }

            resolveAnikotoEmbed(embedUrl, serverName)
        } catch (e: Exception) {
            Log.e(TAG, "getAnikotoEmbedUrl error", e)
            null
        }
    }

    private fun resolveKiwi(malId: String, epNum: String, timestamp: String, type: String): AnikotoStream? {
        for (mapperBase in KIWI_MAPPER_URLS) {
            try {
                val mapperUrl = "$mapperBase/$malId/$epNum/$timestamp"
                val jsonStr = httpGet(mapperUrl, "$baseUrl/")
                val data = JSONObject(jsonStr)

                var serverCode: String? = null
                var directUrl: String? = null

                val keys = data.keys()
                while (keys.hasNext()) {
                    val key = keys.next()
                    if (key == "status") continue
                    val entry = data.optJSONObject(key)?.optJSONObject(type) ?: continue
                    val u = entry.optString("url", "")
                    if (u.isNotBlank()) {
                        if (!u.startsWith("http")) serverCode = u else directUrl = u
                    }
                }

                if (serverCode != null) {
                    val serverRes = httpGet("$baseUrl/ajax/server?get=$serverCode", "$baseUrl/", isAjax = true)
                    var embed = JSONObject(serverRes).optJSONObject("result")?.optString("url")
                    if (!embed.isNullOrBlank()) {
                        if (embed.contains("#")) {
                            val fragment = embed.substringAfter("#")
                            embed = String(Base64.decode(fragment, Base64.DEFAULT), Charsets.UTF_8)
                        }
                        val ref = "https://kwik.cx2.mewcdn.online/"
                        val subs = parseM3u8Subtitles(embed, ref)
                        return AnikotoStream(embedUrl = embed, m3u8 = embed, referer = ref, subtitles = subs, serverName = "Kiwi Stream")
                    }
                }

                if (directUrl != null) {
                    val stream = resolveAnikotoEmbed(directUrl, "Kiwi Stream")
                    if (stream != null) return stream
                }
            } catch (e: Exception) {
                // Try next mapper mirror
            }
        }
        return null
    }

    private fun resolveVidstream(embedUrl: String, referer: String): AnikotoStream? {
        return try {
            val html = httpGet(embedUrl, referer)
            val epId = Regex("""data-ep-id=["'](\d+)["']""").find(html)?.groupValues?.get(1) ?: return null
            val epType = Regex("""type:\s*'(\w+)'""").find(html)?.groupValues?.get(1) ?: return null
            val domain2 = Regex("""domain2_url:\s*'([^']+)'""").find(html)?.groupValues?.get(1)?.trim() ?: return null

            val saveUrl = "$domain2/save_data.php?id=$epId-$epType"
            val saveJsonStr = httpGet(saveUrl, referer)
            val json = JSONObject(saveJsonStr)
            val data = json.optJSONObject("data") ?: return null

            val sources = data.optJSONArray("sources")
            val m3u8 = sources?.optJSONObject(0)?.optString("file") ?: return null

            val tracks = data.optJSONArray("tracks")
            val subs = mutableListOf<AnikotoSubtitle>()
            if (tracks != null) {
                for (i in 0 until tracks.length()) {
                    val t = tracks.optJSONObject(i) ?: continue
                    val file = t.optString("file")
                    if (file.isNotBlank()) {
                        subs.add(AnikotoSubtitle(t.optString("label", "Unknown"), file, t.optBoolean("default", false)))
                    }
                }
            }
            AnikotoStream(embedUrl = embedUrl, m3u8 = m3u8, referer = "$domain2/", subtitles = subs, serverName = "Vidstream")
        } catch (e: Exception) {
            null
        }
    }

    private fun resolveAnikotoEmbed(embedUrl: String, serverName: String): AnikotoStream? {
        return try {
            val host = URI(embedUrl).host.orEmpty()
            val referer = "${URI(embedUrl).scheme}://$host/"
            val html = httpGet(embedUrl, referer)

            if (host.contains("megaplay.buzz") || host.contains("vidwish.live") || host.contains("vidtube.site")) {
                doMegaplay(embedUrl, host, html, referer, serverName)
            } else if (host.contains("megacloud.blog")) {
                doMegacloud(embedUrl, html, referer, serverName)
            } else {
                // Follow iframe redirect
                val iframeMatch = Regex("""<iframe[^>]+src=["']([^"']+)["']""", RegexOption.IGNORE_CASE).find(html)
                if (iframeMatch != null) {
                    val nextUrl = iframeMatch.groupValues[1]
                    val nextFull = if (nextUrl.startsWith("http")) nextUrl else URI(embedUrl).resolve(nextUrl).toString()
                    val nextHost = URI(nextFull).host.orEmpty()
                    val nextRef = "${URI(nextFull).scheme}://$nextHost/"
                    val nextHtml = httpGet(nextFull, nextRef)
                    if (nextHost.contains("megaplay") || nextHost.contains("vidwish") || nextHost.contains("vidtube")) {
                        return doMegaplay(nextFull, nextHost, nextHtml, nextRef, serverName)
                    } else if (nextHost.contains("megacloud")) {
                        return doMegacloud(nextFull, nextHtml, nextRef, serverName)
                    }
                }
                // Return iframe embed fallback if no m3u8 extractor matched
                AnikotoStream(embedUrl = embedUrl, m3u8 = null, referer = referer, serverName = serverName, type = "iframe")
            }
        } catch (e: Exception) {
            null
        }
    }

    private fun doMegaplay(embedUrl: String, host: String, html: String, referer: String, serverName: String): AnikotoStream {
        val fileMatch = Regex("""<title>\s*File\s*([0-9]+)""", RegexOption.IGNORE_CASE).find(html)
        val id = fileMatch?.groupValues?.get(1)
            ?: Regex("""["']id["']\s*:\s*["']?(\d+)["']?""").find(html)?.groupValues?.get(1)
            ?: embedUrl.split("/").firstOrNull { it.all { c -> c.isDigit() } }

        val subs = mutableListOf<AnikotoSubtitle>()
        var m3u8: String? = null

        if (!id.isNullOrBlank()) {
            val getSourcesUrl = "https://$host/stream/getSources?id=$id"
            try {
                val dataStr = httpGet(getSourcesUrl, referer, isAjax = true)
                val data = JSONObject(dataStr)

                m3u8 = data.optJSONObject("sources")?.optString("file")
                if (m3u8.isNullOrBlank() && data.has("enc")) {
                    val enc = data.optString("enc")
                    val decrypted = MegaCrypto.decryptMegaPlaySource(enc, html)
                    if (!decrypted.isNullOrBlank()) {
                        m3u8 = decrypted
                    }
                }

                if (!m3u8.isNullOrBlank() && m3u8.contains("mewstream.buzz")) {
                    m3u8 = m3u8.replace("mewstream.buzz", "1oe.lostproject.club")
                }

                val tracks = data.optJSONArray("tracks")
                if (tracks != null) {
                    for (i in 0 until tracks.length()) {
                        val t = tracks.optJSONObject(i) ?: continue
                        val file = t.optString("file")
                        if (file.isNotBlank()) {
                            subs.add(AnikotoSubtitle(t.optString("label", "Unknown"), file, t.optBoolean("default", false)))
                        }
                    }
                }
            } catch (e: Exception) {
                Log.e(TAG, "doMegaplay getSources error", e)
            }
        }

        val type = if (!m3u8.isNullOrBlank()) "hls" else "iframe"
        return AnikotoStream(
            embedUrl = embedUrl,
            m3u8 = m3u8,
            referer = referer,
            subtitles = subs,
            serverName = serverName,
            type = type
        )
    }

    private fun doMegacloud(embedUrl: String, html: String, referer: String, serverName: String): AnikotoStream? {
        val match1 = Regex("""\b[a-zA-Z0-9]{48}\b""").find(html)?.value
        val match2 = Regex("""\b([a-zA-Z0-9]{16})\b.*?\b([a-zA-Z0-9]{16})\b.*?\b([a-zA-Z0-9]{16})\b""").find(html)
        val nonce = match1 ?: match2?.let { it.groupValues[1] + it.groupValues[2] + it.groupValues[3] } ?: return null

        val uri = URI(embedUrl)
        val origin = "${uri.scheme}://${uri.host}"
        val sId = embedUrl.substringAfter("/e-1/").substringBefore("?").ifBlank {
            embedUrl.substringAfterLast("/").substringBefore("?")
        }
        val sourcesUrl = "$origin/embed-2/v3/e-1/getSources?id=$sId&_k=$nonce"
        val dataStr = httpGet(sourcesUrl, referer, isAjax = true)
        val data = JSONObject(dataStr)

        val sources = data.optJSONArray("sources")
        val m3u8 = sources?.optJSONObject(0)?.optString("file") ?: return null

        val subs = mutableListOf<AnikotoSubtitle>()
        val tracks = data.optJSONArray("tracks")
        if (tracks != null) {
            for (i in 0 until tracks.length()) {
                val t = tracks.optJSONObject(i) ?: continue
                val file = t.optString("file")
                if (file.isNotBlank()) {
                    subs.add(AnikotoSubtitle(t.optString("label", "Unknown"), file, t.optBoolean("default", false)))
                }
            }
        }

        return AnikotoStream(embedUrl = embedUrl, m3u8 = m3u8, referer = referer, subtitles = subs, serverName = serverName)
    }

    private fun parseM3u8Subtitles(m3u8Url: String, referer: String): List<AnikotoSubtitle> {
        val subs = mutableListOf<AnikotoSubtitle>()
        try {
            val content = httpGet(m3u8Url, referer)
            for (line in content.lines()) {
                if (!line.startsWith("#EXT-X-MEDIA") || !line.contains("TYPE=SUBTITLES")) continue
                val uri = Regex("""URI="([^"]+)"""").find(line)?.groupValues?.get(1) ?: continue
                val name = Regex("""NAME="([^"]+)"""").find(line)?.groupValues?.get(1) ?: "Subtitles"
                val isDef = line.contains("DEFAULT=YES", ignoreCase = true)
                val fullUri = if (uri.startsWith("http")) uri else URI(m3u8Url).resolve(uri).toString()
                subs.add(AnikotoSubtitle(name, fullUri, isDef))
            }
        } catch (e: Exception) {
            // Ignore m3u8 parsing errors
        }
        return subs
    }

    // ── Connectivity Check ────────────────────────────────────

    fun testConnection(): Pair<Boolean, String> {
        val start = System.currentTimeMillis()
        var conn: HttpURLConnection? = null
        return try {
            conn = openConnection(baseUrl, method = "HEAD")
            val code = conn.responseCode
            val ms = System.currentTimeMillis() - start
            if (code in 200..399) {
                Pair(true, "Online (HTTP $code) • ${ms}ms")
            } else {
                Pair(false, "HTTP $code • ${ms}ms")
            }
        } catch (e: Exception) {
            Pair(false, "Connection failed: ${e.localizedMessage ?: "timeout"}")
        } finally {
            conn?.disconnect()
        }
    }
}
