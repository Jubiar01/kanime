# Keep readable class & method names (R8 still shrinks unused code by ~94%)
# Avoids Google Play Protect false positives triggered by obfuscated headless APKs
-dontobfuscate

# Keep the exported ContentProvider & info Activity used by KAnime
-keep public class com.kanime.plugin.kanikoto.KanikotoContentProvider {
    public <init>();
    public *;
}
-keep public class com.kanime.plugin.kanikoto.PluginInfoActivity {
    public <init>();
}

# Silence optional/compile-only annotation warnings from Jsoup
-dontwarn org.jsoup.**
-dontwarn org.jspecify.**

# Strip verbose/debug/info logs in release builds
-assumenosideeffects class android.util.Log {
    public static int v(...);
    public static int d(...);
    public static int i(...);
}
